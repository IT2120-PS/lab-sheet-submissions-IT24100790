
1 - pbinom(46, 50, 0.85, lower.tail = TRUE)

dpois(15, 12)




