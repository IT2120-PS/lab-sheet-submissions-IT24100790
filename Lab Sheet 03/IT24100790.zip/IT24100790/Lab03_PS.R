setwd("C:\\Users\\User\\OneDrive\\Desktop\\IT24100790")   
list.files()                      

#Question01
student_data <- read.csv("Exercise.csv")
head(student_data)


#Question02
summary(student_data$X1)
hist(student_data$X1, 
     main = "Histogram of Student Ages",
     xlab = "Age",
     ylab = "Frequency",
     col = "lightblue")


#Question03
gender_table <- table(student_data$X2)
print(gender_table)

barplot(gender_table, 
        main = "Distribution of Gender",
        xlab = "Gender",
        ylab = "Count",
        col = c("lightyellow", "lightblue"))


#Question04
boxplot(X1 ~ X3, 
        data = student_data,
        main = "Age Distribution by Accommodation Type",
        xlab = "Accommodation Type",
        ylab = "Age",
        col = c("lightgreen", "lightyellow", "lightblue"))

